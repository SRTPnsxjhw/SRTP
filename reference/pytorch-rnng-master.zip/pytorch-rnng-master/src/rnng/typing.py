Word = str
POSTag = str
NTLabel = str
Action = str
WordId = int
POSId = int
NTId = int
ActionId = int
